// CSCI 4611 Assignment 5: Artistic Rendering
// You only need to modify the shaders for this assignment.
// You do not need to write any TypeScript code unless
// you are planning to add wizard functionality.

import { MeshViewer } from './MeshViewer'

const meshViewer = new MeshViewer();
meshViewer.start();