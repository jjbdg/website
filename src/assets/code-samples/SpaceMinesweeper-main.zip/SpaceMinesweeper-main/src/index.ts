import { SpaceMinesweeper } from './SpaceMinesweeper'

const app = new SpaceMinesweeper();
app.start();