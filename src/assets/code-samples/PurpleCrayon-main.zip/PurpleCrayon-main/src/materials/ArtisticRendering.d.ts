declare class ArtisticRendering {
    static getToonVertexShader(): string;
    static getToonFragmentShader(): string;
    static getOutlineVertexShader(): string;
    static getOutlineFragmentShader(): string;
}

export { ArtisticRendering };
